/*___Generated_by_IDEA___*/

/** Automatically generated file. DO NOT MODIFY */
package com.pushio.basic;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}